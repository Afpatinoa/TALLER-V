# How to generate a new `sdk.aar`

Follow [Download and build the demo app](https://developers.google.com/cardboard/develop/c/quickstart#download_and_build_the_demo_app),
up to step 3. After assembling the `:sdk` module, copy the generated `.aar` file
(choose the debug or release version according to your needs) and replace
the `sdk.aar` file in this folder with it.
